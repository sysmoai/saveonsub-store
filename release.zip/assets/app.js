/* SAVEONSUB Store — shared app.js (Step 3) */
const WA = "8801305869242";
const BKASH = "+8801305869242";

/* ---------- Cart (localStorage) ---------- */
/* Fail closed: an item is sellable only if it exactly matches a priced plan of a
   non-request_price product in the governed public CATALOG. Price-on-request
   (HOLD) products, unknown plans, edited prices, or a missing CATALOG never
   reach the cart, and stale stored items are dropped on read. */
function cartPlanOk(id, planLabel, bdt, planId){
  if(typeof CATALOG==='undefined' || !CATALOG || !Array.isArray(CATALOG.products)) return false;
  const p=CATALOG.products.find(x=>x && x.id===id);
  if(!p || p.request_price || !Array.isArray(p.plans)) return false;
  return p.plans.some(pl=>pl && pl.label===planLabel && Number(pl.bdt)===Number(bdt) && Number(bdt)>0
    && (!planId || pl.plan_id===undefined || pl.plan_id===planId));
}
function cartGet(){
  let c; try{c=JSON.parse(localStorage.getItem('sos_cart')||'[]')}catch(e){c=[]}
  if(!Array.isArray(c)) return [];
  return c.filter(i=>i && cartPlanOk(i.id, i.plan, i.bdt, i.plan_id) && Number.isInteger(i.qty) && i.qty>0);
}
function cartSet(c){ localStorage.setItem('sos_cart', JSON.stringify(c)); cartBadge(); }
function cartAdd(id, planLabel, bdt, name, planId){
  if(!cartPlanOk(id, planLabel, bdt, planId)){ toast('This plan is price on request — please confirm on WhatsApp'); return; }
  const c = cartGet();
  const stablePlanId = planId || '';
  const ex = c.find(i=>i.id===id && i.plan===planLabel && (i.plan_id||'')===stablePlanId);
  if(ex){ ex.qty++; } else { c.push({id, plan:planLabel, plan_id:stablePlanId, bdt:Number(bdt), name, qty:1}); }
  cartSet(c); toast(`✅ ${name} added — ৳${bdt}`);
}
function cartRemove(idx){ const c=cartGet(); c.splice(idx,1); cartSet(c); if(window.renderCart)renderCart(); }
function cartTotal(){ return cartGet().reduce((s,i)=>s+i.bdt*i.qty,0); }
function cartCount(){ return cartGet().reduce((s,i)=>s+i.qty,0); }
function cartBadge(){ document.querySelectorAll('.cartn').forEach(el=>{ el.textContent=cartCount(); el.style.display=cartCount()?'block':'none'; }); }

/* ---------- Toast ---------- */
function toast(msg){
  let t=document.getElementById('toast');
  if(!t){ t=document.createElement('div'); t.id='toast'; document.body.appendChild(t); }
  t.textContent=msg; t.style.display='block';
  clearTimeout(t._h); t._h=setTimeout(()=>t.style.display='none', 2400);
}

/* ---------- Order ID ---------- */
function orderId(){
  const d=new Date(), p=n=>String(n).padStart(2,'0');
  return `SOS-${String(d.getFullYear()).slice(2)}${p(d.getMonth()+1)}${p(d.getDate())}-${Math.floor(1000+Math.random()*9000)}`;
}

/* ---------- Order record (localStorage) — on-site receipt + fallback ---------- */
function saveOrder(o){
  try{
    localStorage.setItem('sos_last_order', JSON.stringify(o));
    const hist=JSON.parse(localStorage.getItem('sos_orders')||'[]');
    hist.unshift(o); localStorage.setItem('sos_orders', JSON.stringify(hist.slice(0,20)));
  }catch(e){}
}
function lastOrder(){ try{return JSON.parse(localStorage.getItem('sos_last_order')||'null')}catch(e){return null} }

/* ---------- WhatsApp helpers ---------- */
function waLink(text){ return `https://wa.me/${WA}?text=${encodeURIComponent(text)}`; }
function waOrder(extra){
  const c=cartGet();
  const lines=c.map(i=>`• ${i.name} — ${i.plan} ×${i.qty} = ৳${i.bdt*i.qty}`).join('\n');
  return waLink(`🛒 NEW ORDER ${extra&&extra.oid?extra.oid:orderId()}\n${lines}\nTOTAL: ৳${cartTotal()}\nPayment: ${extra&&extra.method?extra.method:'(choosing)'} ${extra&&extra.txn?('TxnID: '+extra.txn):''}\n— sent from saveonsub store`);
}

/* ---------- Real-facts ticker (honest — lifetime records, no fake timestamps) ---------- */
const TICKS=((typeof document!=='undefined'&&document.documentElement&&document.documentElement.lang)||'').indexOf('bn')===0?[
  "পেমেন্টের আগে প্রতিটি প্ল্যানের অ্যাক্সেস টাইপ দেখানো হয়",
  "সব দাম টাকায় দেখানো হয়",
  "প্রতিটি প্ল্যানের সাপোর্ট শর্ত দেখানো থাকে",
  "SaveOnSub-এর হোয়াটসঅ্যাপে মানুষের সাপোর্ট পাবেন",
  "শেয়ার্ড অ্যাক্সেসে প্রাইভেসি ও ধারাবাহিকতার বাড়তি ঝুঁকি থাকতে পারে"
]:[
  "Plans are labeled by access type before payment",
  "Prices are shown in BDT",
  "Support terms are shown by plan",
  "Support is available through the SaveOnSub WhatsApp channel",
  "Shared-access products can carry additional privacy and continuity risk"
];
function startTicker(){
  const el=document.getElementById('tick'); if(!el) return;
  let i=0;
  const show=()=>{ el.textContent=TICKS[i%TICKS.length]; i++; };
  show(); setInterval(show, 4200);
}

/* ---------- Copy ---------- */
function copyText(txt,label){ navigator.clipboard&&navigator.clipboard.writeText(txt).then(()=>toast(`📋 ${label||'Copied'}!`)); }

/* ---------- Mobile nav ---------- */
function navToggle(){ const l=document.querySelector('.navlinks'); if(l) l.classList.toggle('open'); }

/* ---------- PWA: register service worker (offline resilience) ---------- */
if('serviceWorker' in navigator){
  window.addEventListener('load', ()=>{ navigator.serviceWorker.register('/sw.js').catch(()=>{}); });
}
/* Custom install prompt (Android/desktop): capture event, show a subtle button if present */
let sosDeferredPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{
  e.preventDefault(); sosDeferredPrompt=e;
  const b=document.getElementById('installBtn'); if(b){ b.style.display='inline-flex';
    b.onclick=async()=>{ b.style.display='none'; sosDeferredPrompt.prompt(); await sosDeferredPrompt.userChoice; sosDeferredPrompt=null; }; }
});

/* ---------- Bangla language auto-suggest (honest, dismissible, once) ---------- */
function suggestBangla(){
  try{
    if((document.documentElement.lang||'').startsWith('bn')) return;      // already Bangla
    if(localStorage.getItem('sos_lang_dismissed')) return;                 // user said no
    const langs = navigator.languages || [navigator.language || ''];
    if(!langs.some(l => (l||'').toLowerCase().startsWith('bn'))) return;    // not a Bangla browser
    const alt = document.querySelector('link[hreflang="bn-bd"]');
    if(!alt || !alt.href || alt.href === location.href) return;             // no distinct Bangla page
    const bar = document.createElement('div');
    bar.setAttribute('role','region'); bar.setAttribute('aria-label','ভাষা');
    bar.style.cssText='position:fixed;left:12px;right:12px;bottom:12px;z-index:9999;max-width:520px;margin:0 auto;'
      +'background:var(--card,#103433);border:1px solid var(--green,#14d4b8);border-radius:14px;'
      +'padding:12px 14px;display:flex;align-items:center;gap:12px;box-shadow:0 8px 30px rgba(0,0,0,.4);font-size:14.5px';
    bar.innerHTML='<span style="flex:1">🇧🇩 বাংলায় দেখতে চান? <b>এই পেজটি বাংলায়ও আছে।</b></span>'
      +'<a class="btn btn-primary btn-sm" href="'+alt.href+'">বাংলায় দেখুন</a>'
      +'<button aria-label="বন্ধ করুন" style="background:none;border:none;color:var(--muted,#a3c9c4);font-size:20px;cursor:pointer;line-height:1">✕</button>';
    bar.querySelector('button').onclick=function(){ try{localStorage.setItem('sos_lang_dismissed','1')}catch(e){}; bar.remove(); };
    bar.querySelector('a').onclick=function(){ try{localStorage.setItem('sos_lang_dismissed','1')}catch(e){}; };
    document.body.appendChild(bar);
  }catch(e){}
}

/* ---------- Email Newsletter ---------- */
function setupNewsletterForm(){
  const form = document.getElementById('newsletter-form');
  if(!form) return;
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = form.querySelector('input[type="email"]').value;
    if(!email) return;

    try {
      // Local copy only — the merchant cannot read this. It exists so a repeat
      // visitor is not prompted twice on the same device.
      const subscribers = JSON.parse(localStorage.getItem('sos_subscribers') || '[]');
      if(!subscribers.includes(email)) {
        subscribers.push(email);
        localStorage.setItem('sos_subscribers', JSON.stringify(subscribers));
      }

      // This was previously fetch('https://wa.me/...'), which delivered nothing
      // and told the visitor otherwise. It failed twice over: CSP connect-src
      // 'self' blocked the request outright, and wa.me is a click-to-chat
      // REDIRECTOR, not an ingest endpoint — it would not have recorded the
      // address even if allowed. The .catch(()=>{}) swallowed the violation, so
      // every signup was silently discarded under a success message.
      // window.open is a navigation, not a fetch, so connect-src does not apply
      // and the lead actually reaches the merchant.
      const waMsg = `Newsletter signup: ${email}`;
      const win = window.open(`https://wa.me/${WA}?text=${encodeURIComponent(waMsg)}`, '_blank');

      if (win) {
        toast('Opening WhatsApp — send the message to confirm your signup.');
        form.reset();
      } else {
        // Popup blocked: say so rather than claim success.
        toast('Please allow popups, or message us on WhatsApp to subscribe.');
      }
    } catch(e) {
      toast('Could not subscribe — please message us on WhatsApp.');
      console.error('Newsletter error:', e);
    }
  });
}

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', ()=>{ cartBadge(); startTicker(); suggestBangla(); setupNewsletterForm(); });

/* motion v1 2026-11-10: scroll reveal, count-up, trust-bar rotation, scroll progress.
   Respects prefers-reduced-motion; without JS everything stays visible. */
(function () {
  if (window.__sosMotion) return; window.__sosMotion = 1;
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }
  ready(function () {
    var root = document.documentElement;
    if (reduce || !('IntersectionObserver' in window)) return;
    root.classList.add('mo');
    var sel = 'main section h2, section > .wrap > h2, .pcard, .cattile, .step, .whyg > div, .fcell, .notice, .box, .tbl, article h2';
    var els = [].slice.call(document.querySelectorAll(sel)).filter(function (el) { return !el.closest('.hero'); });
    // motion v2: siblings ripple out by distance on the grid (column + row from the
    // first card), so a row of cards lands left to right and the next row follows.
    var groups = new Map();
    els.forEach(function (el) { var p = el.parentElement; (groups.get(p) || groups.set(p, []).get(p)).push(el); });
    groups.forEach(function (list) {
      var rs = list.map(function (el) { return el.getBoundingClientRect(); });
      var x0 = Math.min.apply(null, rs.map(function (r) { return r.left; }));
      var y0 = Math.min.apply(null, rs.map(function (r) { return r.top; }));
      list.forEach(function (el, i) {
        var r = rs[i], w = r.width || 1, h = r.height || 1;
        var rank = Math.round((r.left - x0) / w) + Math.round((r.top - y0) / h);
        el.classList.add('rv'); el.style.setProperty('--d', Math.min(rank, 6) * 0.07 + 's');
      });
    });
    var io = new IntersectionObserver(function (es) {
      // also reveal anything already scrolled past (a fast flick can skip the in-view moment)
      es.forEach(function (e) { if (e.isIntersecting || e.boundingClientRect.top < 0) { e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    // a heading hidden by its mask has no visible area, so watch its parent instead
    var proxy = new Map();
    var io2 = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting && e.boundingClientRect.top >= 0) return; io2.unobserve(e.target);
        (proxy.get(e.target) || []).forEach(function (h) { h.classList.add('in'); });
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0 });
    els.forEach(function (el) {
      var r = el.getBoundingClientRect();
      if (r.top < innerHeight && r.bottom > 0) { el.classList.add('in'); return; }
      if (el.tagName === 'H2' && el.parentElement) {
        var p = el.parentElement; if (!proxy.has(p)) { proxy.set(p, []); io2.observe(p); } proxy.get(p).push(el);
      } else io.observe(el);
    });
    // count-up for the facts band
    var bn = '০১২৩৪৫৬৭৮৯';
    var cio = new IntersectionObserver(function (es) {
      es.forEach(function (e) {
        if (!e.isIntersecting) return; cio.unobserve(e.target);
        var el = e.target, to = +el.getAttribute('data-count'), isBn = el.hasAttribute('data-bn'), t0 = null;
        function fmt(n) { var s = String(n); return isBn ? s.replace(/\d/g, function (d) { return bn[d]; }) : s; }
        function step(ts) { if (!t0) t0 = ts; var k = Math.min(1, (ts - t0) / 1100); el.textContent = fmt(Math.round(to * (1 - Math.pow(1 - k, 3)))); if (k < 1) requestAnimationFrame(step); }
        requestAnimationFrame(step);
      });
    }, { threshold: 0.4 });
    [].forEach.call(document.querySelectorAll('.fnum[data-count]'), function (el) { cio.observe(el); });
    // trust bar: on phones show one message at a time
    var tb = document.querySelector('.trustbar .wrap');
    if (tb && matchMedia('(max-width: 760px)').matches) {
      var spans = [].slice.call(tb.children); var k = 0;
      if (spans.length > 1) setInterval(function () {
        spans[k].style.display = 'none'; spans[k].classList.remove('tb-in');
        k = (k + 1) % spans.length; spans[k].style.display = 'inline'; spans[k].classList.add('tb-in');
      }, 3800);
    }
    // thin scroll-progress line
    var bar = document.createElement('div'); bar.className = 'scrollbar-top'; bar.setAttribute('aria-hidden', 'true');
    document.body.appendChild(bar);
    var ticking = false;
    addEventListener('scroll', function () {
      if (ticking) return; ticking = true;
      requestAnimationFrame(function () {
        var h = root.scrollHeight - innerHeight; bar.style.transform = 'scaleX(' + (h > 0 ? scrollY / h : 0) + ')'; ticking = false;
      });
    }, { passive: true });
  });
})();

/* guide pages: build a table of contents from the h2 headings (no-JS readers see the
   article unchanged; headings stay real h2 for search engines). */
(function () {
  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }
  if (typeof document === 'undefined' || typeof document.querySelector !== 'function') return;
  ready(function () {
    var main = document.querySelector('main[data-bangla-guide]'); if (!main || main.querySelector('.guide-toc')) return;
    var wrap = main.querySelector('.wrap'); if (!wrap) return;
    var hs = [].slice.call(wrap.querySelectorAll(':scope > h2'));
    if (hs.length < 4) return;
    var bn = (document.documentElement.lang || '').indexOf('bn') === 0 || /[ঀ-৿]/.test(hs[0].textContent);
    var nav = document.createElement('div'); nav.className = 'guide-toc'; nav.setAttribute('role', 'navigation'); nav.setAttribute('aria-label', bn ? 'এই গাইডে যা আছে' : 'In this guide');
    var title = document.createElement('b'); title.textContent = bn ? 'এই গাইডে যা আছে' : 'In this guide'; nav.appendChild(title);
    var ol = document.createElement('ol');
    hs.forEach(function (h, i) {
      if (!h.id) h.id = 'sec-' + (i + 1);
      var li = document.createElement('li'), a = document.createElement('a');
      a.href = '#' + h.id; a.textContent = h.textContent; li.appendChild(a); ol.appendChild(li);
    });
    nav.appendChild(ol);
    hs[0].parentNode.insertBefore(nav, hs[0]);
  });
})();

/* motion v3 2026-11-13: neural-network hero + pointer spotlight (canvas hook from tech_motion.py).
   Starts when the page is idle, caps pixel density, fewer nodes on phones, pauses off screen
   or in a hidden tab, and never runs under reduced motion or Save-Data. */
(function () {
  if (typeof document === 'undefined' || typeof document.querySelector !== 'function' || typeof window === 'undefined') return;
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var saveData = navigator.connection && navigator.connection.saveData;
  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }
  ready(function () {
    var fine = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;
    // pointer spotlight on cards (desktop only)
    if (fine && !reduce) {
      document.addEventListener('pointermove', function (e) {
        var c = e.target && e.target.closest && e.target.closest('.pcard, .cattile, .whyg > div, .fcell, .step');
        if (!c) return;
        var r = c.getBoundingClientRect();
        c.style.setProperty('--mx', (e.clientX - r.left) + 'px'); c.style.setProperty('--my', (e.clientY - r.top) + 'px');
      }, { passive: true });
    }
    var cv = document.querySelector('canvas.neural-fx');
    if (!cv || !cv.getContext || reduce || saveData) return;
    var ctx = cv.getContext('2d'); if (!ctx) return;
    var hero = cv.closest('.hero') || cv.parentNode;
    var W = 0, H = 0, dpr = 1, nodes = [], pulses = [], links = [], D = 130, running = false, visible = true, raf = 0, last = 0;
    var ptr = { x: -1e4, y: -1e4 };
    var COLS = ['46,240,210', '124,199,255', '167,139,250'];
    var phone = innerWidth < 761;
    function size() {
      var r = hero.getBoundingClientRect();
      dpr = Math.min(window.devicePixelRatio || 1, phone ? 1.25 : 1.5);
      W = Math.max(1, r.width); H = Math.max(1, r.height);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      D = phone ? 105 : 140;
      var n = Math.round(Math.min(phone ? 30 : 70, Math.max(18, W * H / (phone ? 13000 : 17000))));
      while (nodes.length < n) nodes.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .22, vy: (Math.random() - .5) * .22, r: 1 + Math.random() * 1.6, c: COLS[Math.random() < .6 ? 0 : Math.random() < .6 ? 1 : 2], ph: Math.random() * 6.28 });
      nodes.length = n;
    }
    function spawn() {
      if (!links.length) return;
      var l = links[(Math.random() * links.length) | 0];
      pulses.push({ a: l[0], b: l[1], t: 0, sp: .012 + Math.random() * .018, hops: 2 + ((Math.random() * 4) | 0) });
    }
    function frame(ts) {
      raf = 0; if (!running) return;
      raf = requestAnimationFrame(frame);
      if (phone && ts - last < 32) return; // ~30 fps on phones
      last = ts;
      ctx.clearRect(0, 0, W, H);
      var i, j, a, b, dx, dy, d2, D2 = D * D;
      for (i = 0; i < nodes.length; i++) {
        a = nodes[i];
        dx = ptr.x - a.x; dy = ptr.y - a.y; d2 = dx * dx + dy * dy;
        if (d2 < 32400) { a.vx += dx * 4e-5; a.vy += dy * 4e-5; }
        a.vx *= .995; a.vy *= .995;
        var sp = Math.hypot(a.vx, a.vy); if (sp < .05) { a.vx += (Math.random() - .5) * .04; a.vy += (Math.random() - .5) * .04; }
        a.x += a.vx; a.y += a.vy;
        if (a.x < -20) a.x = W + 20; else if (a.x > W + 20) a.x = -20;
        if (a.y < -20) a.y = H + 20; else if (a.y > H + 20) a.y = -20;
      }
      links = [];
      ctx.lineWidth = 1;
      for (i = 0; i < nodes.length; i++) {
        a = nodes[i];
        for (j = i + 1; j < nodes.length; j++) {
          b = nodes[j]; dx = a.x - b.x; dy = a.y - b.y; d2 = dx * dx + dy * dy;
          if (d2 < D2) {
            links.push([i, j]);
            ctx.strokeStyle = 'rgba(' + a.c + ',' + (0.16 * (1 - d2 / D2)).toFixed(3) + ')';
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        dx = ptr.x - a.x; dy = ptr.y - a.y; d2 = dx * dx + dy * dy;
        if (d2 < 32400) { ctx.strokeStyle = 'rgba(46,240,210,' + (0.28 * (1 - d2 / 32400)).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(ptr.x, ptr.y); ctx.stroke(); }
      }
      for (i = 0; i < nodes.length; i++) {
        a = nodes[i]; a.ph += .03;
        ctx.fillStyle = 'rgba(' + a.c + ',' + (0.45 + Math.sin(a.ph) * .25).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(a.x, a.y, a.r, 0, 6.283); ctx.fill();
      }
      // data pulses travel along links and hop to a neighbour
      if (pulses.length < (phone ? 5 : 11) && Math.random() < .06) spawn();
      for (i = pulses.length - 1; i >= 0; i--) {
        var p = pulses[i], A = nodes[p.a], B = nodes[p.b];
        if (!A || !B) { pulses.splice(i, 1); continue; }
        p.t += p.sp;
        var x = A.x + (B.x - A.x) * p.t, y = A.y + (B.y - A.y) * p.t;
        var g = ctx.createRadialGradient(x, y, 0, x, y, 9);
        g.addColorStop(0, 'rgba(210,255,248,.95)'); g.addColorStop(.35, 'rgba(46,240,210,.5)'); g.addColorStop(1, 'rgba(46,240,210,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.283); ctx.fill();
        ctx.strokeStyle = 'rgba(46,240,210,.55)'; ctx.lineWidth = 1.4;
        var tx = A.x + (B.x - A.x) * Math.max(0, p.t - .35), ty = A.y + (B.y - A.y) * Math.max(0, p.t - .35);
        ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(x, y); ctx.stroke(); ctx.lineWidth = 1;
        if (p.t >= 1) {
          var nb = [];
          for (j = 0; j < links.length; j++) { if (links[j][0] === p.b && links[j][1] !== p.a) nb.push(links[j][1]); else if (links[j][1] === p.b && links[j][0] !== p.a) nb.push(links[j][0]); }
          if (--p.hops > 0 && nb.length) { p.a = p.b; p.b = nb[(Math.random() * nb.length) | 0]; p.t = 0; } else pulses.splice(i, 1);
        }
      }
    }
    function play() { var on = visible && !document.hidden; if (on && !running) { running = true; raf = requestAnimationFrame(frame); } else if (!on) { running = false; if (raf) cancelAnimationFrame(raf); raf = 0; } }
    function start() {
      size(); cv.classList.add('on');
      if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { visible = es[0].isIntersecting; play(); }).observe(hero);
      document.addEventListener('visibilitychange', play);
      var rt; addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { phone = innerWidth < 761; size(); }, 200); }, { passive: true });
      if (fine) {
        hero.addEventListener('pointermove', function (e) { var r = hero.getBoundingClientRect(); ptr.x = e.clientX - r.left; ptr.y = e.clientY - r.top; }, { passive: true });
        hero.addEventListener('pointerleave', function () { ptr.x = ptr.y = -1e4; });
      }
      play();
    }
    if ('requestIdleCallback' in window) requestIdleCallback(start, { timeout: 1500 }); else setTimeout(start, 700);
  });
})();


/* phones: slide the floating buttons away while reading downwards and in the footer,
   so they never sit on top of cards or text. Without JS they simply stay (small, round). */
(function () {
  if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return;
  function ready(fn) { document.readyState !== 'loading' ? fn() : document.addEventListener('DOMContentLoaded', fn); }
  ready(function () {
    var fabs = document.querySelectorAll('.fab'); if (!fabs.length) return;
    var mq = window.matchMedia ? window.matchMedia('(max-width: 760px)') : { matches: false };
    var last = window.pageYOffset || 0, inFooter = false, ticking = false;
    function set(away) { for (var i = 0; i < fabs.length; i++) fabs[i].classList.toggle('fab-away', away); }
    var foot = document.querySelector('footer');
    if (foot && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { inFooter = es[0].isIntersecting; if (inFooter) set(true); }, { threshold: 0.05 }).observe(foot);
    }
    addEventListener('scroll', function () {
      if (ticking) return; ticking = true;
      requestAnimationFrame(function () {
        var y = window.pageYOffset || 0, d = y - last;
        if (!mq.matches) { set(false); }
        else if (inFooter || (d > 8 && y > 120)) { set(true); }
        else if (d < -8 || y <= 120) { set(false); }
        if (Math.abs(d) > 8) last = y;
        ticking = false;
      });
    }, { passive: true });
  });
})();
